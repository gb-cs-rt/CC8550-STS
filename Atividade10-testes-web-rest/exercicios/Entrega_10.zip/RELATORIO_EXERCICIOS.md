# Relatório dos Exercícios
_Data: 24/10/2025_

**Autor:** 
- Pedro Henrique Lega Kramer Costa
- Ruan Pastrelo Turola
- Felipe Orlando Lanzara

**Turma/Disciplina:** CC8550 - SIMULAÇÃO E TESTE DE SOFTWARE - Grupo N

---

# Exercicios

## Exercício 1 — Teste de Login (Web)
Automatização de testes com **Selenium/pytest** para o formulário de login do site de prática (`https://practicetestautomation.com/practice-test-login/`), cobrindo cinco cenários: sucesso com as credenciais válidas (`student`/`Password123`), email inválido, senha incorreta, envio sem preencher campos e verificação de mensagens de erro; asserções confirmam o texto “Logged In Successfully” após login correto e, nos casos negativos, a permanência na página de login com avisos apropriados e sem redirecionamento.

![Captura da tela](Imagens/Captura1.png)

---

## Exercício 2 — API de Produtos (REST)
Testes de API com **requests/pytest** para a `Fake Store API`, cobrindo: listagem de produtos, busca por ID, filtro por categoria, validação de schema básico dos itens e respeito ao limite de retorno; asserções verificam **status codes 200**, estrutura mínima dos campos (ex.: `title`, `price`, `category`) e a presença das categorias esperadas (*electronics*, *jewelery*, *men's clothing*, *women's clothing*), garantindo respostas consistentes e filtragens corretas.

![Captura da tela](Imagens/Captura2.png)
---

## Exercício 3 — Teste CRUD Completo (REST)
Validação do ciclo **CRUD** no endpoint `/todos` do **JSONPlaceholder**, exercitando `POST` (criação de tarefa), `GET` (leitura por ID), `PATCH`/`PUT` (atualização parcial/completa) e `DELETE` (remoção); o fluxo encerra com verificação de inexistência (ex.: `404` ou corpo vazio), uso de **fixtures** para dados temporários, checagens de **status codes** e cobertura de cenários de erro (como criação sem campos obrigatórios), assegurando comportamento previsível da API.

![Captura da tela](Imagens/Captura3.png)
---

## Exercício 4 — Page Object Model (Web)
Refatoração dos testes de login para o padrão **Page Object Model (POM)**, separando responsabilidades em `BasePage`, `LoginPage` e `DashboardPage`: a `LoginPage` expõe locators e métodos (`abrir`, `preencher_email`, `preencher_senha`, `clicar_login`, `fazer_login`), enquanto a `DashboardPage` concentra verificações de estado (`esta_logado`, `obter_mensagem_boas_vindas`); os testes ficam mais legíveis e estáveis ao descrever intenções, com seletores e ações encapsulados nas páginas.

![Captura da tela](Imagens/Captura4.png)
---

## Exercício 5 — Testes Parametrizados (REST + Web)
Conjunto de testes **parametrizados** para ampliar cobertura com pouco código: (A) validação de emails inválidos via `reqres.in` espera **HTTP 400** em tentativas de registro com formatos incorretos; (B) validação de senhas fracas retorna **400** para combinações curtas, só números, sem maiúscula etc.; (C) busca Web parametrizada (ex.: Google) confirma que o termo pesquisado aparece nos resultados, demonstrando variação de entradas e asserções consistentes em **REST** e **UI**.

![Captura da tela](Imagens/Captura5.png)
---